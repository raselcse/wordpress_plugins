<?php if ( $apply = get_the_job_application_method() ) :
	wp_enqueue_script( 'wp-job-manager-job-application' );
	?>
	<div class="job_application application">
		<?php do_action( 'job_application_start', $apply ); ?>
		
		<input type="button" class="application_button button" value="<?php _e( 'Apply for job', 'wp-job-manager' ); ?>" />
		
		<div class="application_details">
		    <?php
			if ( is_user_logged_in() ) {
    
            ?>
			<form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post" enctype="multipart/form-data"> 
				<div class="row">
					<div class="col-sm-6">
						<div class="form-group" id="resume-name-group">
							<label for="resume-name">Applicant Name</label>
							<input type="text" name="expected_salary" class="form-control" id="resume-name" placeholder="e.g. 20000">
							<?php global $post;?>
							<input type="hidden" name="job_id" value="<?php echo $post->ID; ?>">
							<input type="hidden" name="action" value="apply_job">
						</div>

					</div>
				</div>

				<div class="row text-center">
					<div class="col-sm-6">
						<p>&nbsp;</p>
						<input type="submit" class="btn btn-primary btn-lg" value="Submit">
					</div>
				</div>
				
			</form>
			<?php
			}
			else{
				
			echo "For Apply Job, Please Login First. To login";
			?>
			<a href="http://localhost/jobs/login/">Click here</a>
			<?php }
			?>

		</div>
		<?php do_action( 'job_application_end', $apply ); ?>
	</div>
<?php endif; ?>
