/* global job_manager_chosen_multiselect_args */
jQuery(function(){
	jQuery( '.job-manager-category-dropdown' ).chosen( job_manager_chosen_multiselect_args );
});
