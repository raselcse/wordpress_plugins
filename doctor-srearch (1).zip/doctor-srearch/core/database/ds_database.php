<?php
	class Ds_database{
		protected $tables;
		public function __construct(){
			global $wpdb;
		
		}
	}