=== Doctor Search ===
Contributors: OployeeLabs
Stable tag: 1.0
Tested up to: 4.7
Requires at least: 4.3

Doctor search of doctorola.com .

== Description ==
 if you want add Doctor search funtionality of Bangladesh, you can choose us. Visitor's can search doctor with speciality, city and area using Doctor search form. By using this plugins, you can also use as widget.Also you can put anywhere in your website using shortcode([doctor_search_form]). 
 
== Installation ==
 
 
1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
 
== Frequently Asked Questions ==
 
= What is the shortcode for use Doctor search form? =
 
you can use ['doctor_search_form'].
 
= How I can use Doctor search form using Widget? =
 
In your widget section you will see a widget name as Doctor Search then you can drug and drop as you like anywhere.
 
== Screenshots ==
 
 
== Arbitrary section ==
 

 


