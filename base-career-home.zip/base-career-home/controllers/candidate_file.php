<?php
	class Candidate_file extends Basecareer_controller{
		
		function __construct()
		{
			parent::__construct();
		}

		

		 
		public function getAllCandidateFile(){
			$load              = new Basecareer_load();
			$prescriptionModel         = $load->model('candidate_experience');
		    $allPrescriptionOrder['allprescription'] = $prescriptionModel->getAllCandidate('candidate_experience');
            $load->view('candidate/job-list');
		   
		   //echo "test";
		}
		public function addNewFile($msg = null){
			$load              = new Basecareer_load();
			$load->view('candidate/candidant_apply_job', $msg);
		}
		
	    // Random code generator used for file names.
		function prescription_generate_random_code($length=10) {
		 
		   $string = '';
		   $characters = "23456789";
		 
		   for ($p = 0; $p < $length; $p++) {
			   $string .= $characters[mt_rand(0, strlen($characters)-1)];
		   }
		 
		   return $string;
		 
		}
		
		function fileSave(){
			 $data = array();
			$parent_post_id = isset( $_POST['post_id'] ) ? $_POST['post_id'] : 0;  // The parent ID of our attachments
			$valid_formats = array("docx", "pdf", "png", "bmp", "jpeg"); // Supported file types
			$max_file_size = 1024 * 500; // in kb
			$max_image_upload = 10; // Define how many images can be uploaded to the current post
			$wp_upload_dir = wp_upload_dir();
			$path = $wp_upload_dir['path'] . '/';
			$count = 0;

			$attachments = get_posts( array(
				'post_type'         => 'attachment',
				'posts_per_page'    => -1,
				'post_parent'       => $parent_post_id,
				'exclude'           => get_post_thumbnail_id() // Exclude post thumbnail to the attachment count
			) );

			// Image upload handler
			if( $_SERVER['REQUEST_METHOD'] == "POST" ){
				
				// Check if user is trying to upload more than the allowed number of images for the current post
				if( ( count( $attachments ) + count( $_FILES['candidate_cv_file']['name'] ) ) > $max_image_upload ) {
					$upload_message[] = "Sorry you can only upload " . $max_image_upload . " images for each Ad";
				} else {
					
					foreach ( $_FILES['candidate_cv_file']['name'] as $f => $name ) {
						$extension = pathinfo( $name, PATHINFO_EXTENSION );
						// Generate a randon code for each file name
						$new_filename = $this->prescription_generate_random_code(5). '_order_file.' . $extension;
						
						if ( $_FILES['candidate_cv_file']['error'][$f] == 4 ) {
							continue; 
						}
						
						if ( $_FILES['candidate_cv_file']['error'][$f] == 0 ) {
							// Check if image size is larger than the allowed file size
							if ( $_FILES['candidate_cv_file']['size'][$f] > $max_file_size ) {
								$upload_message[] = "$name is too large!.";
								continue;
							
							// Check if the file being uploaded is in the allowed file types
							} elseif( ! in_array( strtolower( $extension ), $valid_formats ) ){
								$upload_message[] = "$name is not a valid format";
								continue; 
							
							} else{ 
								// If no errors, upload the file...
								if( move_uploaded_file( $_FILES["candidate_cv_file"]["tmp_name"][$f], $path.$new_filename ) ) {
									
									$count++; 

									$filename = $path.$new_filename;
									var_dump($filename);
									$filetype = wp_check_filetype( basename( $filename ), null );
									$wp_upload_dir = wp_upload_dir();
									$attachment = array(
										'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ), 
										'post_mime_type' => $filetype['type'],
										'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
										'post_content'   => '',
										'post_status'    => 'inherit'
									);
									// Insert attachment to the database
									$attach_id = wp_insert_attachment( $attachment, $filename, $parent_post_id );

									require_once( ABSPATH . 'wp-admin/includes/image.php' );
									
									// Generate meta data
									$attach_data = wp_generate_attachment_metadata( $attach_id, $filename ); 
									wp_update_attachment_metadata( $attach_id, $attach_data );
									
								}
							}
						}
					}
				}
			}
		$current_user = wp_get_current_user();
		$data['candidate_userid']  = $current_user->ID;
		$data['file_name'] = $filename;
	
		$data['content']= $attach_id;
		
		$load = new Basecareer_load();
		$labTestModel = $load->model('model_candidate_file');
		$success_insert = $labTestModel->save('candidate_file' , $data);
		var_dump($data);
		// $msg['success_msg'] = "Your Prescription order request has been submitted";
			// $to = 'raselsec@gmail.com';
			// $subject = 'The subject';
			// $body = 'The email body content';
			// //$headers[] = 'From: Me Myself <me@example.net>';
			// //$headers[] = 'Cc: John Q Codex <jqc@wordpress.org>';
			// //$headers[] = 'Cc: iluvwp@wordpress.org'; // note you can just use a simple email address
			 
			// //wp_mail( $to, $subject, $body, $headers );
			// wp_mail( $to, $subject, $body );
		// $msg = array();
		// if($success_insert){
			// $msg['success_msg'] = "Your Prescription order request has been submitted";
			// $to = 'raselsec@gmail.com';
			// $subject = 'The subject';
			// $body = 'The email body content';
			// $headers[] = 'From: Me Myself <me@example.net>';
			// $headers[] = 'Cc: John Q Codex <jqc@wordpress.org>';
			// $headers[] = 'Cc: iluvwp@wordpress.org'; // note you can just use a simple email address
			 
			// //wp_mail( $to, $subject, $body, $headers );
			// wp_mail( $to, $subject, $body );
		// }
		// else{
			// $msg['error_msg'] = "Prescription order request has not submitted";
		// }
		
	}

		
		
	
		public function getCandidateById(){
			$load              = new Basecareer_load();
			$labTestModel         = $load->model('model_candidate_experience');
			$id                = $_GET['id'];
			$allPrescriptionOrder['allprescription'] = $labTestModel->getByIdPrescription('candidate_experience',$id);
            $load->view('prescription/edit_prescription' , $allPrescriptionOrder);
		}
		public function updateFile(){
			$id                       = $_REQUEST['id'];
			$prescription_order_status = $_REQUEST['prescription_order_status'];

            
			$data             = array();
			$data['prescription_order_status']  = $prescription_order_status;
            var_dump($data['prescription_order_status']);
			$load = new Pres_load();
			$labTestModel = $load->model('model_candidate_experience');
			$success_update = $labTestModel->updatePrescription('candidate_experience',$data,$id);
			$msg = array();
			if($success_update){
				$msg['success_msg'] = "Data has been Updated";
			}
			else{
				$msg['error_msg'] = "Not Updated";
			}
			$allPrescriptionOrder['allprescription'] = $labTestModel->getAllPrescription('candidate_experience');
			$load->view('prescription/edit_prescription' ,$allPrescriptionOrder, $msg);
		}
		public function deleteCandidateFile(){
			$load             	 = new Basecareer_load();
			$labTestModel        = $load->model('model_candidate_experience');
			$id                  = $_GET['id'];
			$getPrescription = $labTestModel->getByIdPrescription('candidate_experience',$id);
			$media_id = $getPrescription[0]->prescription_media_id;
			$deleteLabTest       = $labTestModel->deleteByIdPrescription('candidate_experience',$id);
			$allPrescriptionOrder['allprescription'] = $labTestModel->getAllPrescription('candidate_experience');
			$msg = array();
			
			if($deleteLabTest){
				$msg['success_msg'] = "Data has been Deleted";
				wp_delete_attachment( $media_id );
			}
			else{
				$msg['error_msg'] = "Not Deleted";
			}
            $load->view('prescription/all_prescription' , $allPrescriptionOrder, $msg);
		}
	
}