<?php
	class Basecareer_database{
		protected $tables;
		public function __construct(){
			global $wpdb;
		
		}
	}